import React from 'react';
import Layout from './layout';
import Demo from './demo';

export default function Index() {
  return (
    <Layout>
      <Demo />
    </Layout>
  );
}
